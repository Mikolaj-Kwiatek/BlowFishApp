﻿using System;
using System.IO;
using blowform;
using Xunit;

namespace UnitTests
{
    public class FileEncryptionTests
    {
        [Fact]
        public void ShouldEncryptAndThenDecrypt()
        {
            // given
            var sut = new FileEncryption();
            sut.GenerateEncryptionKey();
            // and
            var inputFile = createFileWithContent("TEST");
            // and
            var encryptedFile = new FileInfo(Path.GetTempFileName());
            var decryptedFile = new FileInfo(Path.GetTempFileName());
            // and
            sut.encrypt(inputFile, encryptedFile);

            // when
            sut.decrypt(encryptedFile, decryptedFile);

            // then
            Assert.Equal(
                new[]
                {
                    "TEST"
                },
                File.ReadAllLines(decryptedFile.FullName)
            );
        }

        private FileInfo createFileWithContent(string content)
        {
            var filePath = Path.GetTempFileName();
            File.WriteAllLines(filePath, new[] { content });

            return new FileInfo(filePath);
        }
    }
}