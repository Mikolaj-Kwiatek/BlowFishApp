using System;
using System.Security.Cryptography;

namespace blowform
{
    public class FileEncryptionKeyFactory
    {
        public FileEncryptionKey Generate()
        {
            using (var provider = new AesCryptoServiceProvider())
            {
                provider.GenerateKey();
                return new FileEncryptionKey(provider.Key);
            }
        }

        public FileEncryptionKey FromString(string value)
        {
            return new FileEncryptionKey(Convert.FromBase64String(value));
        }
    }
}