using System;

namespace blowform
{
    public class FileEncryptionKey
    {
        public readonly byte[] key;

        public FileEncryptionKey(byte[] key)
        {
            this.key = key;
        }

        public string asString()
        {
            return Convert.ToBase64String(key);
        }
    }
}