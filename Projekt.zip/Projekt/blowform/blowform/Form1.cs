﻿using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace blowform
{
    public partial class Form1 : Form
    {
        private FileEncryptionKey _key;

        private readonly FileEncryptionKeyFactory _fileEncryptionKeyFactory = new();
        private readonly FileEncryption _fileEncryption = new();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnSelectFile_Click(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                txtFilePath.Text = openFileDialog.FileName;
            }
        }

        private void btnGenerateKey_Click(object sender, EventArgs e)
        {
            _key = _fileEncryptionKeyFactory.Generate();
            txtkey.Text = _key.asString();
        }

        private void btnAddYourKey_Click(object sender, EventArgs e)
        {
            string userInput = Interaction.InputBox("Enter a string:", "", "");
            _key = _fileEncryptionKeyFactory.FromString(userInput);
            txtkey.Text = _key.asString();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            if (!File.Exists(txtFilePath.Text))
            {
                MessageBox.Show("No file.");
                return;
            }

            if (_key == null)
            {
                MessageBox.Show("First generate or enter key.");
                return;
            }

            try
            {
                var inputFile = new FileInfo(txtFilePath.Text);
                var outputFile = new FileInfo(AskUserForSaveFilePath());

                _fileEncryption.encrypt(inputFile, outputFile, _key);

                MessageBox.Show($"File encrypted and saved as {outputFile}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occured: {ex.Message}");
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            var inputFilePath = txtFilePath.Text;

            if (!File.Exists(inputFilePath))
            {
                MessageBox.Show("No file.");
                return;
            }


            if (_key == null)
            {
                MessageBox.Show("First generate or enter key.");
                return;
            }

            try
            {
                var inputFile = new FileInfo(inputFilePath);
                var outputFile = new FileInfo(AskUserForSaveFilePath());

                _fileEncryption.decrypt(inputFile, outputFile, _key);

                MessageBox.Show($"File decrypted and saved as {outputFile}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occured: {ex.Message}");
            }
        }

        private String AskUserForSaveFilePath()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.InitialDirectory = new FileInfo(txtFilePath.Text).DirectoryName;
            saveFileDialog.Title = "Save file as";
            
            if (saveFileDialog.ShowDialog() == DialogResult.OK && !string.IsNullOrWhiteSpace(saveFileDialog.FileName))
            {
                return saveFileDialog.FileName;
            }

            return "";
        }

        private void btn_About_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This application was designed by Mikołaj Kwiatek" +
                " and it was created as part of a programming project, it deals" +
                " with encryption using the Blowfish algorithm and it was created at" +
                " the Network Data Protection Technologies seminar at the" +
                " Catholic University of Lublin", "Popup Window", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnManualClick_Click(object sender, EventArgs e)
        {
            MessageBox.Show("First select a file \n" +
                "then generate key, \n" +
                "you can copy it \n" +
                "from the text box an the right \n" +
                "then click encrypt, choose name \n" +
                "and the directory of encrypted file. \n" +
                "To decrypt choose file and enter a decryption key \n" +
                "choose the directory for the file and a name, \n" +
                "remember to add correct file extension in the name \n" +
                "in case of anny issue restart the " +
                "application. ", "Popup Window", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}