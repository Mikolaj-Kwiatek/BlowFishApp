using System.IO;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.IO;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Parameters;

namespace blowform
{
    public class FileEncryption
    {
        public void encrypt(FileInfo inputFile, FileInfo outputFile, FileEncryptionKey key)
        {
            var cipher = CreateCipher(CipherMode.ENCRYPTION, key);

            using var inputFileStream = inputFile.OpenRead();
            using var outputFileStream = outputFile.OpenWrite();
            using var cipherStream = new CipherStream(outputFileStream, cipher, cipher);
            inputFileStream.CopyTo(cipherStream);
        }

        public void decrypt(FileInfo inputFile, FileInfo outputFile, FileEncryptionKey key)
        {
            var cipher = CreateCipher(CipherMode.DECRYPTION, key);

            using var inputFileStream = inputFile.OpenRead();
            using var outputFileStream = outputFile.OpenWrite();
            using var cipherStream = new CipherStream(outputFileStream, cipher, cipher);
            inputFileStream.CopyTo(cipherStream);
        }
        
        private PaddedBufferedBlockCipher CreateCipher(CipherMode mode, FileEncryptionKey fileEncryptionKey)
        {
            var engine = new BlowfishEngine();
            var parameters = new KeyParameter(fileEncryptionKey.key);
            var cipher = new PaddedBufferedBlockCipher(
                new CbcBlockCipher(engine),
                new ZeroBytePadding()
            );
            var forEncryption = mode == CipherMode.ENCRYPTION;
            cipher.Init(forEncryption, parameters);
            
            return cipher;
        }

        private enum CipherMode
        {
            ENCRYPTION,
            DECRYPTION,
        }
    }
}