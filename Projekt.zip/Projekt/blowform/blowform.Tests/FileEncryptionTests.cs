namespace blowform.Tests;

public class FileEncryptionTests
{
    [Fact]
    public void ShouldEncryptAndThenDecrypt()
    {
        // given
        var sut = new FileEncryption();
        // and
        var key = new FileEncryptionKeyFactory().Generate();
        var inputFile = CreateFileWithContent("TEST");
        // and
        var encryptedFile = new FileInfo(Path.GetTempFileName());
        var decryptedFile = new FileInfo(Path.GetTempFileName());
        // and
        sut.encrypt(inputFile, encryptedFile, key);

        // when
        sut.decrypt(encryptedFile, decryptedFile, key);

        // then
        Assert.Equal(
            new[]
            {
                "TEST"
            },
            File.ReadAllLines(decryptedFile.FullName)
        );
    }

    private FileInfo CreateFileWithContent(string content)
    {
        var filePath = Path.GetTempFileName();
        File.WriteAllLines(filePath, new[] { content });

        return new FileInfo(filePath);
    }
}